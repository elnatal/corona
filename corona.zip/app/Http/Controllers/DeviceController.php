<?php

namespace App\Http\Controllers;

use App\Device;
use Illuminate\Http\Request;

class DeviceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $devices = Device::orderBy('id', 'desc')->paginate(20);
        if ($request->is('api/*')) {
            return $devices;
        } else {
            return view('pages.devices', compact('devices'));
        }
    }

    public function tracker()
    {
        $devices = Device::Where('status', '2')->orWhere('status', '3')->orderBy('id', 'desc')->paginate(20);
        return view('pages.tracker', compact('devices'));
    }

    public function search(Request $request)
    {
        $value = $request->input('q');
        $devices = Device::where('name', 'LIKE', '%' . $value . '%')->orWhere('phone', 'LIKE', '%' . $value . '%')->orWhere('mac_address', 'LIKE', '%' . $value . '%')->orderBy('id', 'desc')->limit(20)->get();

        return view('pages.finder', compact('devices'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'phone' => ['required', 'unique:devices'],
            "mac_address" => 'required'
        ]);
        $device = new Device();
        $device->name = $request->get('name');
        $device->phone = $request->get('phone');
        $device->mac_address = $request->get('mac_address');
        $device->status = "1";
        $device->save();

        return $device;
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($phone)
    {
        return Device::where('phone', $phone)->get();
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $device = Device::findOrFail($id);
        $device->update(['status' => $request->get('status')]);

        return back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
