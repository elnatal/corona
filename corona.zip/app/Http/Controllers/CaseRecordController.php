<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\CaseRecord;

class CaseRecordController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $cases = CaseRecord::orderBy('id', 'desc')->paginate(20);
        if ($request->is('api/*')) {
            return $cases;
        } else {
            return view('pages.case_records', compact('cases'));
        }
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        return CaseRecord::create($request->all());
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return CaseRecord::find($id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $caseRecord = CaseRecord::findOrFail($id);
        $caseRecord->update($request->all());

        return $caseRecord;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $caseRecord = CaseRecord::findOrFail($id);
        $caseRecord->delete();

        return 204;
    }
}
